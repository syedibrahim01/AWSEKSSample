self.__NEXT_FONT_MANIFEST={
  "pages": {
    "/": [
      "static/media/2aaf0723e720e8b9-s.p.woff2"
    ]
  },
  "app": {},
  "appUsingSizeAdjust": false,
  "pagesUsingSizeAdjust": true
}